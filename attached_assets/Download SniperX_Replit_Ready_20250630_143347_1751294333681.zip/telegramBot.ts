import axios from 'axios';
import { config } from './config';

export async function sendTelegram(message: string) {
  const url = `https://api.telegram.org/bot${config.telegramBotToken}/sendMessage`;
  await axios.post(url, {
    chat_id: config.telegramChatId,
    text: message
  });
}
