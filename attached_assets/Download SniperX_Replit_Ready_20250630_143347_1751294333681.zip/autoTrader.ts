import { getTradeCandidate } from './tokenSelector';
import { sendTelegram } from './telegramBot';
import { config } from './config';
import { logTrade } from './tradeLogger';

async function executeBuySellCycle() {
  try {
    const candidate = await getTradeCandidate();

    if (!candidate) return;

    const buyPrice = candidate.price;
    const sellHigh = buyPrice * 1.25;
    const stopLoss = buyPrice * 0.90;

    // Simulate BUY
    logTrade({ type: 'BUY', ...candidate, timestamp: new Date().toISOString() });
    sendTelegram(`✅ Bought ${candidate.symbol} at ${buyPrice} SOL`);

    // Simulate wait...
    const simulatedSellPrice = buyPrice * 1.3; // pretend price moved

    if (simulatedSellPrice >= sellHigh || simulatedSellPrice <= stopLoss) {
      logTrade({ type: 'SELL', symbol: candidate.symbol, price: simulatedSellPrice, timestamp: new Date().toISOString() });
      sendTelegram(`📤 Sold ${candidate.symbol} at ${simulatedSellPrice.toFixed(5)} SOL`);
    }
  } catch (e) {
    console.error('AutoTrader Error:', e.message);
    logTrade({ type: 'ERROR', message: e.message, timestamp: new Date().toISOString() });
  }
}

// Run once or schedule with setInterval
executeBuySellCycle();
