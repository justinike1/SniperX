// Auto-start script for Replit environment
console.log('Running SniperX in Replit...');